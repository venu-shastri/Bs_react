import React from 'react'
import {AddLocationComponent} from './AddLocationComponent'
import {LocationListComponent} from './LoctionListComponent'
import {LocationStoreActions} from './flux/locationStoreActionCreators'
export class  AppComponent extends React.Component{

  constructor(){
      super();
      this.on_AddLocationComponent_Callback=this.on_AddLocationComponent_Callback.bind(this);
      this.state={locations:[]};
  }
  on_AddLocationComponent_Callback(locationObj){

      //Dispatch  Action
      let action=LocationStoreActions.createAddLocationAction(locationObj);
      this.props.fluxInstance.DispatcherInstance.dispatch(action);
  }
componentDidMount(){
    //subscribe for store
    this.storeRef=this.props.fluxInstance.stores["locationStore"];
    this.storeRef.subscribe(this.viewCallback.bind(this));
}
viewCallback(){

    //pull the state from store and update component state using setState()
    let locationsFromStore=this.storeRef.getState();
    this.setState({locations:locationsFromStore});

}
  render(){
      return(
            <div>
                    <AddLocationComponent
                     callback={this.on_AddLocationComponent_Callback}></AddLocationComponent>
                <LocationListComponent locations={this.state.locations}></LocationListComponent>
            </div>
  );
}
}
