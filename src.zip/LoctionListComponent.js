import React from 'react'
import {LocationListItemComponent} from './LocationListIItemComponent'
export function LocationListComponent(props){

    let locationListItemComponents=[];
    props.locations.forEach(location => {

      let itemComponent=
        <LocationListItemComponent location={location}></LocationListItemComponent>
        locationListItemComponents.push(itemComponent);
    });


    return(
        <fieldset>
            <legend>Locations</legend>
            <ul>
            {locationListItemComponents}
        </ul>
        </fieldset>

        
    )

}