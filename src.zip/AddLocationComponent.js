import React from 'react'
export class AddLocationComponent extends React.Component{


    constructor(){
        super();
        this.on_add_location_click=this.on_add_location_click.bind(this);
        this.on_location_name_changed=this.on_location_name_changed.bind(this);
        this.locationObj={};
    }
    on_add_location_click(){
            this.props.callback({...this.locationObj});
    }
    on_location_name_changed(event){

        //textbox value 
        this.locationObj.locationName=event.target.value;

    }

    render(){

        return(
            <fieldset>
            <legend>
                Add New Location
                </legend>
                <p>
                    <input onChange={this.on_location_name_changed} type="text" id="locationEditCtrl"/>
                    <button onClick={this.on_add_location_click}>AddLocation</button>
                </p>
         
        </fieldset>
        );
    }

}