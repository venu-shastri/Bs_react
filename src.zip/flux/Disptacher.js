class Dispatcher{

    constructor(){
        this.storeCallbacks=[];
    }
    dispatch(action){

        this.storeCallbacks.forEach(storeCallback=>{
            storeCallback(action);
        });
    }

    subscribe(storeCallback){

            this.storeCallbacks.push(storeCallback);
    }

}
export const DispatcherInstance= new Dispatcher();