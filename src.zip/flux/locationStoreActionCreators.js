import {LocationStoreActionNames} from './locationStoreActionNames'
export const LocationStoreActions={

    createAddLocationAction:function(data) {

        return {type:LocationStoreActionNames.ADD_LOCATION,data:data};
        
    }
}