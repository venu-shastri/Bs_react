import {LocationStoreActionNames} from './locationStoreActionNames'
export class LocationStore{
    constructor()
    {
        this.locations=[];
        this.callback=this.callback.bind(this);
    }

    getState(){
        return this.locations;
    }

    callback(action){
        switch(action.type){
            case LocationStoreActionNames.ADD_LOCATION:
            this.locations.push(action.data);    
            //notify-views(components
            this.notify();
            break;
        }
    }
}