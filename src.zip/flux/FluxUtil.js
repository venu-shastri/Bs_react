 export class FluxUtil{


    constructor(dispatcherInstance){
        this.DispatcherInstance=dispatcherInstance;
        this.stores={};
    }

    setNewDispatcher(dispactherInstance)
    {
        this.DispatcherInstance=dispactherInstance;
    }

    createStore(name,store)
    {
        this.DispatcherInstance.subscribe(store.callback.bind(store));
        this.stores[name]=this.storeMixin(store);

    }
    storeMixin(store)
    {
        store.viewCallbacks=[];
        store.subscribe=function(viewCallback) {
            this.viewCallbacks.push(viewCallback);
        }
        store.notify=function name(params) {
            
            this.viewCallbacks.forEach(viewCallback=>{
                viewCallback();
            });
        }
        return store;
    }

}

