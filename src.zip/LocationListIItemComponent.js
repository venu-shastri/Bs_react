
import React from 'react'
export function LocationListItemComponent(props){


    return(
        <li>{props.location.locationName}</li>
    )

}