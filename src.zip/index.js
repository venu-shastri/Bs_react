import React from 'react'
import {AppComponent} from './App'
import ReactDom from 'react-dom'

import {DispatcherInstance} from './flux/Disptacher';
import {LocationStore} from './flux/LocationStore';
import {FluxUtil} from './flux/FluxUtil';


let fluxInstance=new FluxUtil(DispatcherInstance);
fluxInstance.createStore("locationStore",new LocationStore());

ReactDom.render(<AppComponent fluxInstance={fluxInstance}/>,document.getElementById('root'));
